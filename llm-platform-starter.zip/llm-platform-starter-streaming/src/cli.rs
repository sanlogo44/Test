use clap::{Parser, Subcommand};
use std::net::SocketAddr;

#[derive(Debug, Parser)]
#[command(
    name = "llm-platform",
    version,
    about = "Local-first LLM intelligence platform"
)]
pub struct Cli {
    /// SQLite connection URL. Example: sqlite://llm-platform.db
    #[arg(
        long,
        global = true,
        env = "LLM_PLATFORM_DATABASE_URL",
        default_value = "sqlite://llm-platform.db"
    )]
    pub database_url: String,

    #[command(subcommand)]
    pub command: Commands,
}

#[derive(Debug, Subcommand)]
pub enum Commands {
    /// Database migration and inspection commands.
    Db {
        #[command(subcommand)]
        command: DbCommands,
    },
    /// Inspectably restructure a prompt without making an inference request.
    Prompt {
        #[command(subcommand)]
        command: PromptCommands,
    },
    /// Send a prompt to a registered OpenAI-compatible provider.
    Chat {
        /// Registered model external ID (or display name).
        model: String,
        /// User prompt.
        prompt: String,
        /// Optional system instruction.
        #[arg(long)]
        system: Option<String>,
    },
    /// Start the local HTTP API (loopback by default).
    Serve {
        #[arg(long, default_value = "127.0.0.1:8787")]
        bind: SocketAddr,
    },
    /// Manage model-provider records.
    Providers {
        #[command(subcommand)]
        command: ProviderCommands,
    },
    /// Manage registered models.
    Models {
        #[command(subcommand)]
        command: ModelCommands,
    },
}

#[derive(Debug, Subcommand)]
pub enum DbCommands {
    /// Apply forward-only SQLx migrations. This is explicit; startup never migrates automatically.
    Migrate,
    /// Show the migration state of the configured database.
    Status,
}

#[derive(Debug, Subcommand)]
pub enum ProviderCommands {
    /// Register a provider without storing credentials in the database.
    Add {
        name: String,
        #[arg(long, default_value = "local")]
        provider_type: String,
        #[arg(long)]
        endpoint: Option<String>,
    },
    /// List registered providers.
    List,
}

#[derive(Debug, Subcommand)]
pub enum ModelCommands {
    /// Register an existing local or remote model. This does not download or execute it.
    Register {
        #[arg(long)]
        provider: String,
        #[arg(long)]
        external_id: String,
        #[arg(long)]
        display_name: String,
        #[arg(long)]
        local_path: Option<String>,
        #[arg(long)]
        context_window: Option<i64>,
    },
    /// List registered models.
    List,
}


#[derive(Debug, Subcommand)]
pub enum PromptCommands {
    /// Format a request into a stable prompt structure.
    Optimize {
        /// Original user request.
        prompt: String,
        /// conservative preserves scope; advanced adds general quality guidance.
        #[arg(long, default_value = "conservative", value_parser = ["conservative", "advanced"])]
        mode: String,
    },
}

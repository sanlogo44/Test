//! Persistent SQLite-backed job queue primitives.
//!
//! A lease is a temporary claim, not a guarantee that work ran exactly once.
//! Handlers should be idempotent because a worker can crash after performing
//! an external side effect but before acknowledging completion.

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use sqlx::{Row, SqlitePool};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Job {
    pub id: String,
    pub job_type: String,
    pub payload: serde_json::Value,
    pub status: String,
    pub attempt_count: i64,
    pub maximum_attempts: i64,
    pub lease_owner: Option<String>,
    pub lease_expires_at: Option<String>,
}

/// Add a job. Reusing an idempotency key returns the existing job.
pub async fn enqueue(
    pool: &SqlitePool,
    job_type: &str,
    payload: &serde_json::Value,
    priority: i64,
    maximum_attempts: i64,
    idempotency_key: Option<&str>,
) -> Result<Job> {
    anyhow::ensure!(!job_type.trim().is_empty(), "job type must not be empty");
    anyhow::ensure!(maximum_attempts > 0, "maximum_attempts must be positive");
    let id = Uuid::new_v4().to_string();
    let payload_json = serde_json::to_string(payload)?;

    let inserted = sqlx::query(
        "INSERT INTO jobs (id, job_type, payload_json, priority, maximum_attempts, idempotency_key) \
         VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(idempotency_key) DO NOTHING",
    )
    .bind(&id)
    .bind(job_type)
    .bind(payload_json)
    .bind(priority)
    .bind(maximum_attempts)
    .bind(idempotency_key)
    .execute(pool)
    .await
    .context("failed to enqueue job")?;

    let selected_id = if inserted.rows_affected() == 1 {
        id
    } else {
        sqlx::query_scalar::<_, String>("SELECT id FROM jobs WHERE idempotency_key = ?")
            .bind(idempotency_key)
            .fetch_one(pool)
            .await
            .context("idempotency key conflicted but existing job was not found")?
    };
    get(pool, &selected_id).await?.context("enqueued job not found")
}

pub async fn get(pool: &SqlitePool, id: &str) -> Result<Option<Job>> {
    let row = sqlx::query(
        "SELECT id, job_type, payload_json, status, attempt_count, maximum_attempts, lease_owner, lease_expires_at \
         FROM jobs WHERE id = ?",
    )
    .bind(id)
    .fetch_optional(pool)
    .await?;
    row.map(|row| -> Result<Job> {
        let payload: String = row.try_get("payload_json")?;
        Ok(Job {
            id: row.try_get("id")?,
            job_type: row.try_get("job_type")?,
            payload: serde_json::from_str(&payload)?,
            status: row.try_get("status")?,
            attempt_count: row.try_get("attempt_count")?,
            maximum_attempts: row.try_get("maximum_attempts")?,
            lease_owner: row.try_get("lease_owner")?,
            lease_expires_at: row.try_get("lease_expires_at")?,
        })
    })
    .transpose()
    .context("failed to decode job row")
}

/// Atomically claim the highest-priority due job and record its attempt.
pub async fn claim(pool: &SqlitePool, worker_id: &str, lease_seconds: i64) -> Result<Option<Job>> {
    anyhow::ensure!(!worker_id.trim().is_empty(), "worker_id must not be empty");
    anyhow::ensure!(lease_seconds > 0, "lease_seconds must be positive");
    let mut tx = pool.begin().await?;
    let row = sqlx::query(
        "UPDATE jobs SET status = 'running', attempt_count = attempt_count + 1, \
         started_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), \
         lease_owner = ?, lease_expires_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '+' || ? || ' seconds'), \
         updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') \
         WHERE id = (SELECT id FROM jobs WHERE status = 'queued' AND attempt_count < maximum_attempts \
         AND scheduled_at <= strftime('%Y-%m-%dT%H:%M:%fZ','now') \
         ORDER BY priority DESC, scheduled_at ASC, created_at ASC LIMIT 1) \
         RETURNING id, job_type, payload_json, status, attempt_count, maximum_attempts, lease_owner, lease_expires_at",
    )
    .bind(worker_id)
    .bind(lease_seconds)
    .fetch_optional(&mut *tx)
    .await?;

    if let Some(row) = row {
        let id: String = row.try_get("id")?;
        let attempt: i64 = row.try_get("attempt_count")?;
        sqlx::query(
            "INSERT INTO job_attempts (id, job_id, attempt_number, worker_id, status) VALUES (?, ?, ?, ?, 'running')",
        )
        .bind(Uuid::new_v4().to_string())
        .bind(&id)
        .bind(attempt)
        .bind(worker_id)
        .execute(&mut *tx)
        .await?;
        tx.commit().await?;
        get(pool, &id).await
    } else {
        tx.commit().await?;
        Ok(None)
    }
}

pub async fn complete(pool: &SqlitePool, job_id: &str, worker_id: &str, result_reference: Option<&str>) -> Result<bool> {
    let mut tx = pool.begin().await?;
    let result = sqlx::query(
        "UPDATE jobs SET status = 'completed', completed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), \
         lease_owner = NULL, lease_expires_at = NULL, result_reference = ?, \
         updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ? AND status = 'running' AND lease_owner = ?",
    )
    .bind(result_reference)
    .bind(job_id)
    .bind(worker_id)
    .execute(&mut *tx)
    .await?;
    if result.rows_affected() == 1 {
        sqlx::query("UPDATE job_attempts SET status = 'completed', completed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE job_id = ? AND status = 'running'")
            .bind(job_id).execute(&mut *tx).await?;
    }
    tx.commit().await?;
    Ok(result.rows_affected() == 1)
}

/// Fail a claimed job. It is re-queued if attempts remain; otherwise dead-lettered.
pub async fn fail(pool: &SqlitePool, job_id: &str, worker_id: &str, error_code: &str, error_summary: &str) -> Result<bool> {
    let mut tx = pool.begin().await?;
    let row = sqlx::query(
        "SELECT attempt_count, maximum_attempts FROM jobs WHERE id = ? AND status = 'running' AND lease_owner = ?",
    ).bind(job_id).bind(worker_id).fetch_optional(&mut *tx).await?;
    let Some(row) = row else { tx.commit().await?; return Ok(false); };
    let attempt_count: i64 = row.try_get("attempt_count")?;
    let maximum_attempts: i64 = row.try_get("maximum_attempts")?;
    let status = if attempt_count >= maximum_attempts { "dead_letter" } else { "queued" };
    sqlx::query(
        "UPDATE jobs SET status = ?, error_code = ?, lease_owner = NULL, lease_expires_at = NULL, \
         completed_at = CASE WHEN ? = 'dead_letter' THEN strftime('%Y-%m-%dT%H:%M:%fZ','now') ELSE NULL END, \
         updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?",
    ).bind(status).bind(error_code).bind(status).bind(job_id).execute(&mut *tx).await?;
    sqlx::query(
        "UPDATE job_attempts SET status = 'failed', completed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), error_summary = ? WHERE job_id = ? AND status = 'running'",
    ).bind(error_summary).bind(job_id).execute(&mut *tx).await?;
    tx.commit().await?;
    Ok(true)
}

/// Recover expired leases after a crash. Exhausted jobs are dead-lettered.
pub async fn recover_expired_leases(pool: &SqlitePool) -> Result<u64> {
    let mut tx = pool.begin().await?;
    sqlx::query(
        "UPDATE job_attempts SET status = 'abandoned', completed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), \
         error_summary = 'worker lease expired' WHERE status = 'running' AND job_id IN \
         (SELECT id FROM jobs WHERE status = 'running' AND lease_expires_at <= strftime('%Y-%m-%dT%H:%M:%fZ','now'))",
    ).execute(&mut *tx).await?;
    let result = sqlx::query(
        "UPDATE jobs SET status = CASE WHEN attempt_count >= maximum_attempts THEN 'dead_letter' ELSE 'queued' END, \
         lease_owner = NULL, lease_expires_at = NULL, \
         completed_at = CASE WHEN attempt_count >= maximum_attempts THEN strftime('%Y-%m-%dT%H:%M:%fZ','now') ELSE NULL END, \
         error_code = 'lease_expired', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') \
         WHERE status = 'running' AND lease_expires_at <= strftime('%Y-%m-%dT%H:%M:%fZ','now')",
    ).execute(&mut *tx).await?;
    tx.commit().await?;
    Ok(result.rows_affected())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::db;
    use sqlx::sqlite::SqlitePoolOptions;

    async fn pool() -> SqlitePool {
        let pool = SqlitePoolOptions::new().max_connections(1)
            .connect("sqlite::memory:").await.expect("open test database");
        db::migrate(&pool).await.expect("apply schema");
        pool
    }

    #[tokio::test]
    async fn enqueue_is_idempotent_and_claim_completes() {
        let pool = pool().await;
        let payload = serde_json::json!({"prompt":"hello"});
        let first = enqueue(&pool, "test", &payload, 5, 2, Some("request-1")).await.unwrap();
        let second = enqueue(&pool, "test", &payload, 5, 2, Some("request-1")).await.unwrap();
        assert_eq!(first.id, second.id);
        let claimed = claim(&pool, "worker-a", 60).await.unwrap().unwrap();
        assert_eq!(claimed.id, first.id);
        assert_eq!(claimed.attempt_count, 1);
        assert!(claim(&pool, "worker-b", 60).await.unwrap().is_none());
        assert!(complete(&pool, &first.id, "wrong-worker", None).await.unwrap() == false);
        assert!(complete(&pool, &first.id, "worker-a", Some("result-1")).await.unwrap());
        assert_eq!(get(&pool, &first.id).await.unwrap().unwrap().status, "completed");
    }

    #[tokio::test]
    async fn failed_jobs_retry_then_dead_letter() {
        let pool = pool().await;
        let job = enqueue(&pool, "test", &serde_json::json!({}), 0, 1, None).await.unwrap();
        let claimed = claim(&pool, "worker-a", 60).await.unwrap().unwrap();
        assert!(fail(&pool, &claimed.id, "worker-a", "test_error", "failed").await.unwrap());
        assert_eq!(get(&pool, &job.id).await.unwrap().unwrap().status, "dead_letter");
        assert!(claim(&pool, "worker-b", 60).await.unwrap().is_none());
    }
}

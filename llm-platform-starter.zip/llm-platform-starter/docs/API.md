# Phase 1 HTTP API

The server binds to loopback only. These routes are unauthenticated and must not be exposed to a network.

| Method | Path | Purpose |
|---|---|---|
| GET | `/health/live` | Process-level liveness check |
| GET | `/health/ready` | Verifies the database responds to `SELECT 1` |
| GET | `/v1/models` | Lists registered models belonging to enabled providers |

`/v1/models` returns an array of objects containing `id`, `display_name`, `external_model_id`, `provider_name`, `status`, and nullable `context_window`. The `registered` status means only that metadata is in the database; it does not mean a model is loaded or currently available.

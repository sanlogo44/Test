# Development status

## Completed in the initial slice

- [x] Retained the two supplied prompts under `specs/`.
- [x] Defined a Rust CLI and module boundaries.
- [x] Added a versioned SQLite foundation migration.
- [x] Added explicit migration and migration-status commands.
- [x] Added provider registration/listing, endpoint validation, and transactional audit events.
- [x] Added model metadata registration/listing with no execution side effects and transactional audit events.
- [x] Added live/readiness and database-backed model-listing HTTP endpoints.
- [x] Refused non-loopback API binds until authentication exists.
- [x] Added schema checks and architecture/security documentation.
- [x] Authored Rust unit/API tests for registry round-trips, endpoint validation, and route behavior (execution remains unverified here).

## Not yet verified in this environment

The execution environment used to create this starter does not currently have `rustc`, `cargo`, or `rustfmt` installed. Rust compilation, formatting checks, `cargo test`, and end-to-end HTTP tests have therefore **not been run** here. A `Cargo.lock` also could not be generated in this environment. The portable Python/SQLite schema test is separate and does not imply that the Rust code compiles.

## Next work items

- [ ] Run `cargo fmt --check`, `cargo clippy --all-targets --all-features -- -D warnings`, and `cargo test` in a Rust-enabled environment.
- [ ] Execute existing Rust tests and extend coverage to readiness/database failures and server-bind restrictions.
- [ ] Add transaction-safe job claiming, leases, retries and restart recovery.
- [ ] Implement the real first local inference adapter, including capability detection and cancellation.
- [ ] Add configuration versioning and structured error codes.
- [ ] Add PostgreSQL migrations only when the persistence abstraction and tests can verify equivalent behavior.
- [ ] Add authentication/authorization before any remote or multi-user operation.

mod api;
mod cli;
mod db;
mod registry;

use anyhow::{Context, Result};
use clap::Parser;
use cli::{Cli, Commands, DbCommands, ModelCommands, ProviderCommands};
use tracing_subscriber::EnvFilter;

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info")),
        )
        .with_target(false)
        .init();

    let cli = Cli::parse();
    let pool = db::connect(&cli.database_url).await?;

    match cli.command {
        Commands::Db {
            command: DbCommands::Migrate,
        } => {
            db::migrate(&pool).await?;
            println!("Database migrations applied successfully.");
        }
        Commands::Db {
            command: DbCommands::Status,
        } => db::status(&pool).await?,
        Commands::Providers { command } => {
            db::require_migrated(&pool).await?;
            match command {
                ProviderCommands::Add {
                    name,
                    provider_type,
                    endpoint,
                } => {
                    let id = registry::add_provider(
                        &pool,
                        &name,
                        &provider_type,
                        endpoint.as_deref(),
                    )
                    .await?;
                    println!("Provider registered: {name} ({id})");
                    println!(
                        "Note: credentials are intentionally not accepted or stored by this command."
                    );
                }
                ProviderCommands::List => {
                    let providers = registry::list_providers(&pool).await?;
                    if providers.is_empty() {
                        println!("No providers registered.");
                    }
                    for provider in providers {
                        println!(
                            "{}\t{}\t{}\t{}",
                            provider.name,
                            provider.provider_type,
                            provider.endpoint.as_deref().unwrap_or("(no endpoint)"),
                            if provider.enabled { "enabled" } else { "disabled" }
                        );
                    }
                }
            }
        }
        Commands::Models { command } => {
            db::require_migrated(&pool).await?;
            match command {
                ModelCommands::Register {
                    provider,
                    external_id,
                    display_name,
                    local_path,
                    context_window,
                } => {
                    let id = registry::register_model(
                        &pool,
                        &provider,
                        &external_id,
                        &display_name,
                        local_path.as_deref(),
                        context_window,
                    )
                    .await?;
                    println!("Model registered: {display_name} ({id})");
                    println!(
                        "Registration does not prove runtime compatibility or model availability."
                    );
                }
                ModelCommands::List => {
                    let models = registry::list_models(&pool).await?;
                    if models.is_empty() {
                        println!("No models registered.");
                    }
                    for model in models {
                        println!(
                            "{}\t{}\tprovider={}\tstatus={}\tcontext={}",
                            model.display_name,
                            model.external_model_id,
                            model.provider_name,
                            model.status,
                            model
                                .context_window
                                .map(|value| value.to_string())
                                .unwrap_or_else(|| "unknown".to_string())
                        );
                    }
                }
            }
        }
        Commands::Serve { bind } => {
            if !bind.ip().is_loopback() {
                anyhow::bail!(
                    "this Phase 1 API has no authentication; refusing non-loopback bind {bind}"
                );
            }
            db::require_migrated(&pool).await?;
            let listener = tokio::net::TcpListener::bind(bind)
                .await
                .with_context(|| format!("could not bind HTTP listener to {bind}"))?;
            tracing::info!(address = %listener.local_addr()?, "HTTP API listening");
            axum::serve(listener, api::router(pool))
                .await
                .context("HTTP server failed")?;
        }
    }

    Ok(())
}

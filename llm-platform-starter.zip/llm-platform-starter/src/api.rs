use crate::{db, registry};
use axum::{
    extract::State,
    http::StatusCode,
    routing::get,
    Json, Router,
};
use serde_json::{json, Value};
use sqlx::SqlitePool;
use tracing::error;

pub fn router(pool: SqlitePool) -> Router {
    Router::new()
        .route("/health/live", get(live))
        .route("/health/ready", get(ready))
        .route("/v1/models", get(models))
        .with_state(pool)
}

async fn live() -> Json<Value> {
    Json(json!({ "status": "ok" }))
}

async fn ready(State(pool): State<SqlitePool>) -> Result<Json<Value>, StatusCode> {
    match sqlx::query_scalar::<_, i64>("SELECT 1")
        .fetch_one(&pool)
        .await
    {
        Ok(_) => Ok(Json(json!({ "status": "ready", "database": "ok" }))),
        Err(err) => {
            error!(error = %err, "readiness check failed");
            Err(StatusCode::SERVICE_UNAVAILABLE)
        }
    }
}

async fn models(
    State(pool): State<SqlitePool>,
) -> Result<Json<Vec<registry::ModelListItem>>, StatusCode> {
    if let Err(err) = db::require_migrated(&pool).await {
        error!(error = %err, "model endpoint unavailable because schema is not ready");
        return Err(StatusCode::SERVICE_UNAVAILABLE);
    }

    registry::list_models(&pool).await.map(Json).map_err(|err| {
        error!(error = %err, "failed to list models");
        StatusCode::INTERNAL_SERVER_ERROR
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::{body::Body, http::Request};
    use http_body_util::BodyExt;
    use sqlx::sqlite::SqlitePoolOptions;
    use tower::ServiceExt;

    async fn test_pool() -> SqlitePool {
        SqlitePoolOptions::new()
            .max_connections(1)
            .connect("sqlite::memory:")
            .await
            .expect("in-memory database should open")
    }

    #[tokio::test]
    async fn live_endpoint_reports_ok() {
        let response = router(test_pool().await)
            .oneshot(
                Request::builder()
                    .uri("/health/live")
                    .body(Body::empty())
                    .expect("request should build"),
            )
            .await
            .expect("router should respond");

        assert_eq!(response.status(), StatusCode::OK);
        let body = response
            .into_body()
            .collect()
            .await
            .expect("body should collect")
            .to_bytes();
        let value: Value = serde_json::from_slice(&body).expect("response should be JSON");
        assert_eq!(value["status"], "ok");
    }

    #[tokio::test]
    async fn model_endpoint_requires_schema_migrations() {
        let response = router(test_pool().await)
            .oneshot(
                Request::builder()
                    .uri("/v1/models")
                    .body(Body::empty())
                    .expect("request should build"),
            )
            .await
            .expect("router should respond");
        assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    }

    #[tokio::test]
    async fn model_endpoint_lists_models_after_migration() {
        let pool = test_pool().await;
        db::migrate(&pool).await.expect("migration should apply");
        let response = router(pool)
            .oneshot(
                Request::builder()
                    .uri("/v1/models")
                    .body(Body::empty())
                    .expect("request should build"),
            )
            .await
            .expect("router should respond");

        assert_eq!(response.status(), StatusCode::OK);
        let body = response
            .into_body()
            .collect()
            .await
            .expect("body should collect")
            .to_bytes();
        let value: Value = serde_json::from_slice(&body).expect("response should be JSON");
        assert_eq!(value, json!([]));
    }
}

# Local-First LLM Intelligence Platform

A Rust-first, CLI-driven foundation for a local LLM platform. This repository implements the first **foundation vertical slice** from the supplied specifications: explicit SQLite migrations, provider/model registration, model listing, and a loopback-only HTTP API with live/readiness endpoints.

> **Scope notice:** this is a working foundation, not the complete platform. It does not yet run inference, download or inspect model weights, authenticate HTTP requests, execute agents, route generation requests, or train models. Model registration is metadata-only and never executes files.

## Requirements

- Rust stable (edition 2021)
- SQLite support is included via SQLx; no separate SQLite CLI is required
- Python 3.11+ only for the portable migration/schema test in `tests/schema_test.py`

The supplied `specs/` files remain in the repository as source requirements.

## Quick start

```bash
# 1. Compile the Rust executable
cargo build

# 2. Create/update the local schema (migrations are explicit, never automatic at startup)
cargo run -- db migrate

# 3. Register a provider and one model record
cargo run -- providers add local-llama --provider-type local
cargo run -- models register \
  --provider local-llama \
  --external-id my-model-q4 \
  --display-name "My local model" \
  --local-path "$HOME/models/my-model.gguf" \
  --context-window 8192

# 4. Inspect database-backed metadata
cargo run -- models list
cargo run -- db status

# 5. Start the HTTP API on loopback only
cargo run -- serve --bind 127.0.0.1:8787
```

Then open these endpoints locally:

- `GET http://127.0.0.1:8787/health/live`
- `GET http://127.0.0.1:8787/health/ready`
- `GET http://127.0.0.1:8787/v1/models`

Provider/model registrations write transactional audit records. Provider endpoint URLs are metadata only in this phase and are not contacted by the application.

The API refuses non-loopback bind addresses until authentication and authorization have been implemented. Do not expose it through a reverse proxy or port-forwarding workaround in this phase.

### Configuration

The database URL can be set with `LLM_PLATFORM_DATABASE_URL` or overridden with `--database-url`. The default is `sqlite://llm-platform.db` in the current working directory. Logging uses `RUST_LOG`, defaulting to `info`.

SQLite foreign keys are enabled on connections and WAL journal mode is requested. Keep the database on a local filesystem and restrict file permissions. Back up the database using SQLite's online backup facilities or after stopping the application; do not treat copying only the main file while WAL is active as a guaranteed consistent backup.

## Test the schema

```bash
python tests/schema_test.py
cargo test
```

The Python test executes the migration using the SQLite library shipped with Python and verifies core constraints. It does **not** replace Rust compilation and SQLx integration tests. Build/test claims should be based on commands actually run in the target environment.

## Current commands

```text
llm-platform db migrate
llm-platform db status
llm-platform providers add <name> [--provider-type <type>] [--endpoint <url>]
llm-platform providers list
llm-platform models register --provider <name> --external-id <id> --display-name <name> [--local-path <path>] [--context-window <tokens>]
llm-platform models list
llm-platform serve [--bind 127.0.0.1:8787]
```

## Repository map

```text
src/                    CLI, SQLite connection/migrations, registry, HTTP API
migrations/sqlite/      Immutable, versioned SQLite SQL migrations
specs/                  Original user-supplied specifications
 tests/                  Portable migration/schema checks
 docs/                   Architecture, security boundaries, implementation status
```

## Current implementation sequence

1. **Foundation (in progress):** SQLite migration, persistent provider/model registry, health and model-listing API.
2. **Inference:** unified model adapter contract and first real local runtime.
3. **Orchestration:** queue workers, explainable router, parallel model runs, prompt optimization.
4. **Agents and automation:** bounded plans, action-level approval, tools, scheduling and crash recovery.
5. **Training and integrations:** datasets, fine-tuning adapters, provider integrations.
6. **Multi-user/GUI:** authentication, authorization, server mode and optional Flutter client.
7. **Production readiness:** reproducible installs, backups, recovery and security review.

See [implementation status](docs/STATUS.md), [architecture](docs/ARCHITECTURE.md), and [security boundaries](docs/SECURITY.md).
